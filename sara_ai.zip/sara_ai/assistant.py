import openai

openai.api_key = 'your-api-key'

class Assistant:
    def chat_gpt3(self, prompt):
        response = openai.ChatCompletion.create(
          model='gpt-3.5-turbo',
          messages=[
                {'role': 'system', 'content': 'You are a helpful assistant.'},
                {'role': 'user', 'content': prompt}
            ]
        )
        return response.choices[0].message['content']