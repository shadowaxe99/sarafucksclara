from flask import Flask, request
from assistant import Assistant

app = Flask(__name__)
assistant = Assistant()

@app.route('/assistant', methods=['POST'])
def handle_assistant():
    data = request.get_json()
    response = assistant.chat_gpt3(data['prompt'])
    return {'message': response}

if __name__ == '__main__':
    app.run(debug=True)