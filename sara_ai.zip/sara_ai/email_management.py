class EmailManagement:
    def __init__(self):
        self.emails = []

    def draft_email(self, email):
        self.emails.append(email)
        return 'EMAIL_DRAFTED'

    def send_email(self, email_id):
        for email in self.emails:
            if email['id'] == email_id:
                # TODO: Implement email sending functionality
                return 'EMAIL_SENT'

    def schedule_email(self, email_id, schedule_time):
        for email in self.emails:
            if email['id'] == email_id:
                email['schedule_time'] = schedule_time
                return 'EMAIL_SCHEDULED'