class TaskManagement:
    def __init__(self):
        self.tasks = []

    def create_task(self, task):
        self.tasks.append(task)
        return 'TASK_CREATED'

    def update_task(self, task_id, updated_task):
        for task in self.tasks:
            if task['id'] == task_id:
                task.update(updated_task)
                return 'TASK_UPDATED'

    def delete_task(self, task_id):
        self.tasks = [task for task in self.tasks if task['id'] != task_id]
        return 'TASK_DELETED'