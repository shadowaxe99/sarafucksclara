class Metrics:
    def __init__(self):
        self.user_satisfaction = 0
        self.engagement_rate = 0
        self.task_completion = 0
        self.schedule_accuracy = 0
        self.email_reliability = 0
        self.customization_level = 0

    def update_metrics(self, metrics):
        self.user_satisfaction = metrics.get('user_satisfaction', self.user_satisfaction)
        self.engagement_rate = metrics.get('engagement_rate', self.engagement_rate)
        self.task_completion = metrics.get('task_completion', self.task_completion)
        self.schedule_accuracy = metrics.get('schedule_accuracy', self.schedule_accuracy)
        self.email_reliability = metrics.get('email_reliability', self.email_reliability)
        self.customization_level = metrics.get('customization_level', self.customization_level)