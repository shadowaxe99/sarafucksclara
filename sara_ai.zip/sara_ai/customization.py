class Customization:
    def __init__(self):
        self.user_preferences = {}

    def set_user_preferences(self, preferences):
        self.user_preferences.update(preferences)
        return 'PREFERENCES_UPDATED'