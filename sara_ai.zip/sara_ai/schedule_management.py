class ScheduleManagement:
    def __init__(self):
        self.appointments = []

    def schedule_appointment(self, appointment):
        self.appointments.append(appointment)
        return 'APPOINTMENT_SCHEDULED'

    def reschedule_appointment(self, appointment_id, updated_appointment):
        for appointment in self.appointments:
            if appointment['id'] == appointment_id:
                appointment.update(updated_appointment)
                return 'APPOINTMENT_RESCHEDULED'

    def view_appointment(self, appointment_id):
        for appointment in self.appointments:
            if appointment['id'] == appointment_id:
                return appointment