GPT3_MODEL = 'gpt-3.5-turbo'
API_KEYS = {
    'openai': 'your-openai-api-key',
    'gmail': 'your-gmail-api-key',
    'google_calendar': 'your-google-calendar-api-key',
    'google_tasks': 'your-google-tasks-api-key',
    'microsoft_graph': 'your-microsoft-graph-api-key',
    'microsoft_outlook_calendar': 'your-microsoft-outlook-calendar-api-key',
    'zoom': 'your-zoom-api-key'
}